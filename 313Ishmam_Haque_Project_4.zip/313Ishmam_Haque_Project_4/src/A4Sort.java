public class A4Sort{
   public static void quickSort(int[] a, int l, int h){
      if (l >= h) return;
      else if(l+15<=h) {
       insertionSort(a,l,h);
      }
      else{
      int pivot = partition(a, l, h);
      quickSort(a, l, pivot - 1); 
      quickSort(a, pivot + 1, h);
      }
   }
   
   
   public static int partition(int[] a, int l, int h){    
      int pivot = a[h];
      //use last entry
      int mid=(l+h)/2;
 	  if(a[h]<a[l]) {
 	   swap(a,l,h);
 	  }       
 	  if(a[mid]<a[l]) {
 	   swap(a,mid,l);
 	  }       
 	  if(a[h]<a[mid]) {
 	    swap(a,h,mid);
 	  }
 	  pivot=a[mid];
      int last = h;
      h--;
      while (l < h){
         while(a[l] < pivot) {
	    	l++;
         }
         while(a[h] > pivot){
	    	h--;
         }
	 	 if (l < h) swap(a,l,h);
	 	 else swap(a,l,last);
      }
      return l;
   }
   
   
   public static void insertionSort(int[] a, int l, int h){
      for (int i =0;i<a.length; i++){
         int j = i;
         int v = a[i];
         while (j > 0 && v < a[j - 1]){
            a[j] = a[j - 1];
            j--;
         }
         a[j] = v;
      }
   }
   public static void swap(int[] a, int i, int j){
      int temp = a[i];
      a[i] = a[j];
      a[j] = temp;
   }
   public static void heapSort(int[] a, int l, int h){
      
      heapify(a); //maxheap
     
   }
   public static void heapify(int[] a){
	   int arraylength=a.length;
	   int counter1=(arraylength/2)-1;
	   int counter2=arraylength-1;
       for (int i=counter1;i>=0;i--) bubbleDown(a,arraylength, i);
       for (int i=counter2;i>0;i--) {
           swap(a,i,0);
           bubbleDown(a,i,0);
       }
   }
   
   public static void bubbleDown(int[] a, int i, int size){
	   int root=size; 
       int leftnode=(2*size)+1; 
       int rightnode=(2*size)+2; 
       if ((leftnode<i)&&(a[leftnode]>a[root])) root=leftnode;
       if ((rightnode<i)&&(a[rightnode]>a[root])) root=rightnode;
       if(root!=size){
           swap(a,size,root);
           bubbleDown(a,i,root);
       }
   }
   public static void main(String[] args){
      int[] a = new int[]{3,19,12,7,15,1,16,4,18,9,13,2,17,5,10,11,14,6,8,20};
      int[] b = new int[]{3,19,12,7,15,1,16,4,18,9,13,2,17,5,10,11,14,6,8,20};
      long time, nextTime;
      System.out.println("quickSort: ");
      time = System.nanoTime();
      quickSort(a, 0, a.length - 1);
      nextTime = System.nanoTime();
      System.out.println("\tTime used: " + (nextTime - time) + " nseconds");
      
      for (int i = 0; i < a.length; i++) System.out.print(a[i] + ",");
      System.out.println();

      System.out.println("heapSort: ");
      heapSort(b, 0, b.length - 1);
      for (int i = 0; i < b.length; i++) System.out.print(b[i] + ",");
      System.out.println();
   }

}

  