import java.util.Stack;
class ExpressionTree{
   private static class BTNode{
      char value;
      BTNode parent, left, right;
      public BTNode(char e){
        this(e, null, null, null);
      }
      public BTNode(char e, BTNode p, BTNode l, BTNode r){
		value = e;
		parent = p;
		left = l;
		right = r;
      }
   }
   BTNode root;
   int numberofparentheses;
   public boolean isoperation(char potential){
	  if((potential=='+')||(potential=='-')||(potential=='*')||(potential=='/')) return true;
	  else return false;
   }   
   public int operationvalue(char potential) {
	 if((potential=='+')||(potential=='-')) return 1;
	 else if((potential=='*')||(potential=='/')) return 2;
	 else if(potential==')') return 0;
	 else return -1;
   }
   public boolean isparantheses(char potential) {
	if(potential==')'||potential=='(') return true;
	else return false;
   }
   public ExpressionTree(String eq){
      root = null;
      Stack<Character> charholder=new Stack<Character>();
      Stack<BTNode> nodeholder=new Stack<BTNode>();
      int enteredlength=eq.length();
      String firstparentheses="(";
      String neweq=firstparentheses+eq;
      neweq=neweq+")";
      numberofparentheses=0;
      for(int i=0;i<neweq.length();i++) {
    	if((neweq.charAt(i)=='(')||(neweq.charAt(i)==')')){ 
    		numberofparentheses++;  
    	}
      }
      int numberofoperations=0;
      int numberofdigits=0;
      for(int j=0;j<neweq.length();j++) {  
    	char currentchar2=neweq.charAt(j);
    	Boolean digitchecker2=Character.isDigit(currentchar2);
    	if(digitchecker2==true) numberofdigits++;
    	else if(isoperation(currentchar2)==true) numberofoperations++;
      }
      if(numberofdigits%2==numberofoperations%2) {
    	  neweq="0";
    	  System.out.println("Operations and digits are broken");
      }
      if(numberofparentheses%2==1) { 
    	  neweq="0";
    	  System.out.println("improper parentheses");
      }
      enteredlength=neweq.length();
      for(int i=0;i<enteredlength;i++) {
    	  char currentchar= neweq.charAt(i);
          Boolean digitchecker= Character.isDigit(currentchar);
          if(currentchar=='(') {
        	  charholder.push(currentchar);
          }
          else if(operationvalue(currentchar)>0) {
          	while((charholder.empty()==false)&&(charholder.peek()!='(')&&(operationvalue(charholder.peek())>=operationvalue(currentchar))) {
          	  BTNode tempnode0= new BTNode(charholder.peek(),null,null,null);
          	  charholder.pop();
          	  BTNode tempnode1= nodeholder.peek();
          	  nodeholder.pop();
          	  BTNode tempnode2= nodeholder.peek();
          	  nodeholder.pop();
          	  tempnode0.left=tempnode2;
          	  tempnode0.right=tempnode1;
          	  tempnode2.parent=tempnode0;
          	  tempnode1.parent=tempnode0;
                nodeholder.push(tempnode0);              
          	}
          	charholder.push(currentchar);
          }
          else if(digitchecker==true) {
           BTNode tempnode0= new BTNode(currentchar,null,null,null);
           nodeholder.push(tempnode0);
          }
          else if(currentchar==')') {
        	  while((charholder.empty()==false)&&(charholder.peek()!='(')){
        		  BTNode tempnode0= new BTNode(charholder.peek(),null,null,null);
            	  charholder.pop();
            	  BTNode tempnode1= nodeholder.peek();
            	  nodeholder.pop();
            	  BTNode tempnode2= nodeholder.peek();
            	  nodeholder.pop();
            	  tempnode0.left=tempnode2;
            	  tempnode0.right=tempnode1;
            	  tempnode2.parent=tempnode0;
            	  tempnode1.parent=tempnode0;
                  nodeholder.push(tempnode0);
        	  }
        	  charholder.pop();
           }
        }
        BTNode tempnode0=nodeholder.peek();
        root=tempnode0;
        }
   public boolean isEmpty(){
      return root == null;
   }
   public void printer(BTNode a) {
	 if((a.left==null)&&(a.right==null)) System.out.print(a.value);
	 else {
		System.out.print("(");
		printer(a.left);
		System.out.print(a.value);
		printer(a.right);
		System.out.print(")");
	 }
   }
   public void print(){
	 if(this.root.value=='0') return;
	 if(this.root!=null) {  
      printer(this.root);
      System.out.println();
	 }
	 else return;
   }

}