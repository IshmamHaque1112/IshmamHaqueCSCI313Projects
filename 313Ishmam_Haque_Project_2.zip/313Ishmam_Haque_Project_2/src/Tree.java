import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

class Tree{
   private static class TNode{
      private int value;
      private TNode parent;
      private List<TNode> children;
      public TNode(){
         this(0, null);
      }
      public TNode(int e){
         this(e, null);
      }
      public TNode(int e, TNode p){
         value = e;
         parent = p;
         children = new ArrayList<TNode>();
      }
   }
   private TNode root;
   private int size;
   Tree(){
      root = null;
      size = 0;
   }
    public TNode createNode(int e, TNode p){
       return new TNode(e, p);
    }
    public TNode addChild(TNode n, int e){
       TNode temp = createNode(e, n);
       n.children.add(temp);
       size++;
       return temp;
    }
    public void makeTree(){
       root = createNode(0, null);
       size++;
       buildTree(root, 3);
    }
    public void makeTree2(){
       root = createNode(0, null); 
       size++; 
       buildTree(root, 1);
    }
    public void makeTree3(){
       root = createNode(3, null); 
       size++; 
    }
    public void makeTree4(){
       root = createNode(2, null); 
       size += 13; 
       buildTree(root, 1);
       size -= 12;
    }
    private void buildTree(TNode n, int i){
       if (i <= 0) return;
       TNode fc = addChild(n, size);
       TNode sc = addChild(n, size);
       TNode tc = addChild(n, size);
       buildTree(fc, i - 1);
       buildTree(sc, i - 2);
       if (i % 2 == 0)
          buildTree(tc, i - 1);
   }
   public ArrayList<ArrayList<Integer>> levelordered(TNode currentnode){
	   ArrayList<ArrayList<Integer>> finallist= new ArrayList<>();
	   if(currentnode==null) return finallist;
	   Queue<TNode> queuenumber= new LinkedList<>();
	   queuenumber.add(currentnode);
	   while(queuenumber.isEmpty()!=true) {
		   int size=queuenumber.size();
           ArrayList<Integer> levelnodes=new ArrayList<>();
           for(int i=0;i<size;i++) {
        	   TNode temp=queuenumber.remove();
        	   levelnodes.add(temp.value);
        	   if(temp.children!=null) {
        		   int childrensize=temp.children.size();
        		   for(int y=0;y<childrensize;y++) {
        			 queuenumber.add(temp.children.get(y));   
        		   }
        	   }
           }
           finallist.add(levelnodes);  
	   }
	   return finallist;
	}
   public ArrayList<ArrayList<TNode>> levelorderednodes(TNode currentnode){
	   ArrayList<ArrayList<TNode>> finallist= new ArrayList<>();
	   if(currentnode==null) return finallist;
	   Queue<TNode> queuenumber= new LinkedList<>();
	   queuenumber.add(currentnode);
	   while(queuenumber.isEmpty()!=true) {
		   int size=queuenumber.size();
           ArrayList<TNode> levelnodes=new ArrayList<>();
           for(int i=0;i<size;i++) {
        	   TNode temp=queuenumber.remove();
        	   levelnodes.add(temp);
        	   if(temp.children!=null) {
        		   int childrensize=temp.children.size();
        		   for(int y=0;y<childrensize;y++) {
        			 queuenumber.add(temp.children.get(y));   
        		   }
        	   }
           }
           finallist.add(levelnodes);  
	   }
	   return finallist;
	}
   public void levelOrder(){
	   ArrayList<ArrayList<Integer>> returnedlist= levelordered(this.root);
	   for(int i=0;i<returnedlist.size();i++) {
		for(int h=0;h<returnedlist.get(i).size();h++) {
		  System.out.print(" "+returnedlist.get(i).get(h));
		}
	   }
	   System.out.println();
	   
   }
   public int levelorderprintnum(TNode a) {
	   int sizeofprint=0;
	   ArrayList<ArrayList<Integer>> returnedlist= levelordered(a);
	   for(int i=0;i<returnedlist.size();i++) {
			for(int h=0;h<returnedlist.get(i).size();h++) {
			 sizeofprint++; 
			}
	    }
		return sizeofprint;
   }
   public boolean TNodesame(TNode a,TNode b) {
	 if(a.value!=b.value) return false;
	 else if(a.children.size()!=b.children.size()) return false;
	 else if(a.parent.value!=b.parent.value) return false;
	 else if(((a.value==b.value)&&(a.children.isEmpty()&&b.children.isEmpty())&&(a.parent.value==b.parent.value))) return true;
	 else {
	   	 for(int i=0;i<a.children.size();i++) {
	   		if(a.children.get(i).value!=b.children.get(i).value) return false;
	   		else if(a.children.get(i).children.size()!=b.children.get(i).children.size()) return false;
	   	 }
	 }
	 return true;
   }
   public boolean TNodearraylistsame(ArrayList<TNode> a,ArrayList<TNode> b) {
	  if(a.size()!=b.size()) return false;
	  else {
		for(int i=0;i<a.size();i++) {
		  if(TNodesame(a.get(i),b.get(i))==false) return false;
		}
	  }
	  return true;
   }
   public boolean levelorderednodessame(ArrayList<ArrayList<TNode>> a,ArrayList<ArrayList<TNode>> b) {
	 if(a.size()!=b.size()) return false;
	 else {
	   for(int i=1;i<a.size();i++) {
		 if(TNodearraylistsame(a.get(i),b.get(i))==false) return false;
	   }
	 }
	 return true;
   }
   public boolean isSubTree(Tree st){
      if(this.root==null) return false;
	   ArrayList<ArrayList<Integer>> returnedlist= levelordered(this.root);
	   ArrayList<ArrayList<Integer>> returnedlist2= levelordered(st.root);
	   ArrayList<ArrayList<TNode>> finallist= levelorderednodes(this.root);
	   ArrayList<ArrayList<TNode>> finallist2=levelorderednodes(st.root);
      int subtreesize=st.size;
      ArrayList<TNode>  nodelist= new ArrayList<>();
      for(int i=0;i<finallist.size();i++) {
  		for(int h=0;h<finallist.get(i).size();h++) {
  		  TNode temptree=finallist.get(i).get(h);	
  		  if(temptree.value==st.root.value) {
  		  	nodelist.add(temptree);
  		  }
  		}
  	   }
      if(nodelist.isEmpty()) return false;
      else if(nodelist.isEmpty()!=true) {
       for(int i=0;i<nodelist.size();i++) {
    	 ArrayList<ArrayList<TNode>> temptree2= levelorderednodes(nodelist.get(i));
    	 if(levelorderednodessame(temptree2,finallist2)==true) return true;
       }        
      }
      return false;
   }
}