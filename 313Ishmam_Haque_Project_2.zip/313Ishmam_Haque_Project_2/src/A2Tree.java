import java.util.*;
public class A2Tree{
   public static void main(String argc[]){
      ExpressionTree et;

      System.out.println("Enter an algebraic expression: ");
      Scanner s = new Scanner(System.in);
      String alg =  s.nextLine();
      s.close();
      
      et = new ExpressionTree(alg);
      et.print();
      et = new ExpressionTree("3+4*5");
      et.print(); //print (3+(4*5))
      et = new ExpressionTree("((1-(2+3))+(4*5))");
      et.print(); //print above
      et = new ExpressionTree("(3(4+5))");
      et.print(); //no output - missing operator
      et = new ExpressionTree("(4+5)*3");
      et.print(); //print ((4+5)*3)
      et = new ExpressionTree("10*((4+5)*2+1)/6");
      et.print(); //print "((10*(((4+5)*2)+1))/6)" However, it will not print, each node can only take a single digit
      et= new ExpressionTree("1+0*((4+5)*2+1)/6"); //print corrected version
      et.print();
      et = new ExpressionTree("((4+5)*3))");
      et.print(); //no output - parenthesis not match
      et = new ExpressionTree("34+5");
      et.print(); //no output - single value only

      Tree t1 = new Tree();
      Tree t2 = new Tree();
      t1.makeTree();
      t1.levelOrder();	//0 1 2 3 4 5 6 13 14 15 7 8 9 10 11 12
      t2.makeTree2();
      t2.levelOrder();	//0 1 2 3
      System.out.println("sub tree t1 and t1 " + t1.isSubTree(t1));
      System.out.println("sub tree t1 and t2 " + t1.isSubTree(t2)); //t2 is not a subTree of t1
      Tree t3 = new Tree();
      t3.makeTree3();
      t3.levelOrder();
      System.out.println("sub tree t1 and t3 " + t1.isSubTree(t3)); //t3 is a subTree of t1
      Tree t4 = new Tree();
      t4.makeTree4();
      t4.levelOrder();
      System.out.println("sub tree t1 and t4 " + t1.isSubTree(t4)); //t4 is a subTree of t1

   }
}