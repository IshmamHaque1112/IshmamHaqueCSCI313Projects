class PolynomialLinkedList{
	private static class PNode{
		private int coe;
		private int exp;
		private PNode next;
		public PNode(int c, int e){
			this(c, e, null);
		}
		public PNode(int c, int e, PNode n){
			coe = c;
			exp = e;
			next = n;
		}
		public void setCoe(int c){ coe = c;}
		public void setExp(int e){ exp = e;}
		public void setNext(PNode n){ next = n;}
		public int getCoe(){ return coe;}
		public int getExp(){ return exp;}
		public PNode getNext(){ return next;}
	}
	private PNode first;
	private PNode last;
	    public PolynomialLinkedList(){
			first = last = null;
		}
		public PolynomialLinkedList(int c, int e){
			PNode tempn = new PNode(c, e);
			first = last = tempn;
		}
		public void print(){
			if (first == null){
				System.out.println();
				return;
			}
			PNode temp = first;
			String ans = "";
			while (temp != null){
				if (temp.getCoe() > 0) {
					if (temp != first) ans = ans + " + ";
					ans = ans + temp.getCoe();
				}
				else if (temp.getCoe() < 0) ans = ans + " - " + temp.getCoe() * -1;
				if (temp.getExp() != 0){
					ans = ans + "X^" + temp.getExp();
				}
				temp = temp.getNext();
			}
			System.out.println(ans);
		}
		public PolynomialLinkedList add(PolynomialLinkedList s){
			PolynomialLinkedList sum = new PolynomialLinkedList();
			PNode firstnode = this.first;
		    PNode secondnode = s.first;
		    while(!(firstnode==null&&secondnode==null)) {
		     PNode thirdnode=null;
		     if(firstnode==null){
		       thirdnode = new PNode(secondnode.getCoe(), secondnode.getExp());  
		       secondnode= secondnode.next; 
		       }
		     else if (secondnode == null){
		       thirdnode = new PNode(firstnode.getCoe(), firstnode.getExp());  
		       firstnode=firstnode.next; 
		       }
		     else if (firstnode.getExp() > secondnode.getExp()) {
		       thirdnode = new PNode(firstnode.getCoe(), firstnode.getExp());  
		       firstnode= firstnode.next; 
		       } 
		     else if (firstnode.getExp() < secondnode.getExp()) {
		       thirdnode = new PNode(secondnode.getCoe(), secondnode.getExp()); 
		       secondnode= secondnode.next; 
		       } 
		     else {
		      int node3coefficient=firstnode.getCoe() + secondnode.getCoe();
		      int node3exponent=firstnode.getExp();
		      firstnode= firstnode.next;
		      secondnode= secondnode.next;
		      if (node3coefficient==0) continue;
		       thirdnode = new PNode(node3coefficient,node3exponent);
		      }
		     if(sum.first==null) {
		      sum.first=sum.last=thirdnode;	 
		     }
		     else {
		      sum.last.next=thirdnode;
		      sum.last=thirdnode;
		     }
		     }
		    while (firstnode!=null) {
			     PNode thirdnode=null;
			     if(firstnode==null){
			       thirdnode = new PNode(secondnode.getCoe(), secondnode.getExp());  
			       secondnode= secondnode.next; 
			       }
			     else if (secondnode == null){
			       thirdnode = new PNode(firstnode.getCoe(), firstnode.getExp());  
			       firstnode=firstnode.next; 
			       }
			     else if (firstnode.getExp() > secondnode.getExp()) {
			       thirdnode = new PNode(firstnode.getCoe(), secondnode.getExp());  
			       firstnode= firstnode.next; 
			       } 
			     else if (firstnode.getExp() < secondnode.getExp()) {
			       thirdnode = new PNode(secondnode.getCoe(), secondnode.getExp()); 
			       secondnode= secondnode.next; 
			       } 
			     else {
			      int node3coefficient=firstnode.getCoe() + secondnode.getCoe();
			      int node3exponent=firstnode.getExp();
			      firstnode= firstnode.next;
			      secondnode= secondnode.next;
			      if (node3coefficient==0) continue;
			       thirdnode = new PNode(node3coefficient,node3exponent);
			      } 
			     if(sum.first==null) {
				      sum.first=sum.last=thirdnode;	 
				  }
				  else {
				   sum.last.next=thirdnode;
				   sum.last=thirdnode;
				  }
			     }
		    while (secondnode!=null) {
			     PNode thirdnode=null;
			     if(firstnode==null){
			       thirdnode = new PNode(secondnode.getCoe(), secondnode.getExp());  
			       secondnode= secondnode.next; 
			       }
			     else if (secondnode == null){
			       thirdnode = new PNode(firstnode.getCoe(), firstnode.getExp());  
			       firstnode=firstnode.next; 
			       }
			     else if (firstnode.getExp() > secondnode.getExp()) {
			       thirdnode = new PNode(firstnode.getCoe(), secondnode.getExp());  
			       firstnode= firstnode.next; 
			       } 
			     else if (firstnode.getExp() < secondnode.getExp()) {
			       thirdnode = new PNode(secondnode.getCoe(), secondnode.getExp()); 
			       secondnode= secondnode.next; 
			       } 
			     else {
			      int node3coefficient=firstnode.getCoe() + secondnode.getCoe();
			      int node3exponent=firstnode.getExp();
			      firstnode= firstnode.next;
			      secondnode= secondnode.next;
			      if (node3coefficient==0) continue;
			       thirdnode = new PNode(node3coefficient,node3exponent);
			      } 
			     if(sum.first==null) {
				      sum.first=sum.last=thirdnode;	 
				 }
				 else {
				  sum.last.next=thirdnode;
				  sum.last=thirdnode;
				 }
			    }
			return sum;
		}
		public PolynomialLinkedList multiply(PolynomialLinkedList s){
			PolynomialLinkedList product = new PolynomialLinkedList();
			PNode node1=this.first;
			PNode node2=s.first;
			while(node1!=null) {
			 while(node2!=null) {
			  PolynomialLinkedList node3= new PolynomialLinkedList(node1.getCoe()*node2.getCoe(),node1.getExp()+node2.getExp());
			  product=product.add(node3);
			  node2=node2.next;
			 }
			 node2=s.first;
			 node1=node1.next;
			}
			return product;
		}
}