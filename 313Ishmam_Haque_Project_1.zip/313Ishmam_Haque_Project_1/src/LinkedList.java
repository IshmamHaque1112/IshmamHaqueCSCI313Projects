class LinkedList<E>{
	private static class Node<E>{
		private E element;
		private Node<E> next;
		public Node(E e, Node<E> n){
			element = e;
			next = n;
		}
		public E getElement(){
			return element;
		}
		public Node<E> getNext(){
			return next;
		}
		public void setElement(E e){
			element = e;
		}
		public void setNext(Node<E> n){
			next = n;
		}
	}
	private Node<E> head;
	public LinkedList(){
		head = null;
	}
	public void add(E e){
		Node<E> temp = new Node<>(e, head);			
		head = temp;
	}
	public void insert(E e, Node<E> p, Node<E> n){
		p.setNext(new Node<>(e, n));      
	}
	public Node<E> getNode(int i) throws Exception{
		Node<E> temp = head;
		while (i > 0){
			if (temp == null) throw new Exception("Out of bound");
			temp = temp.getNext();
			i--;
		}
		return temp;
	}
	public E midElement(){
		int size=0;
		if(this.head==null) {
		 return null;
		}
		else {
			Node<E> nodecounter= this.head;
			while(nodecounter!=null) {
			 size++;
			 nodecounter=nodecounter.next;
			}
		}
		System.out.println("Size is: "+size);
		Node<E> nodecounter2;
		if(size%2==0) {
			try {
				nodecounter2=this.getNode((size/2));
				return nodecounter2.element;
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if(size%2!=0) {
			try {
				nodecounter2=this.getNode((size/2)+1);
				return nodecounter2.element;
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}		
		}
		return null;
				
		}
	public boolean detectLoop(){
		Node<E> nodehead=this.head;
		if(nodehead==null) return false;
		Node <E> nodehead1=nodehead;
		Node <E> nodehead2=nodehead.next;
		while(nodehead1!=nodehead2) {
			if((nodehead2==null) || (nodehead2.next==null)) return false;
			nodehead1=nodehead1.next;
			nodehead2=nodehead2.next.next;
		}
		return true; 
	}
}