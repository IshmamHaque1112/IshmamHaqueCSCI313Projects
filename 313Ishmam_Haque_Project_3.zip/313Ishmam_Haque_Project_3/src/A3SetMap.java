import java.lang.Math; 
import java.io.*;
import java.util.*;
public class A3SetMap{
   public static List<String> readInFile(String filename){
      List<String> input = new ArrayList<>();
      try (Scanner sin = new Scanner(new FileReader(filename))){
         while (sin.hasNextLine()){
	    input.add(sin.nextLine());
         }
      } catch (FileNotFoundException e){
	 e.printStackTrace();
      }
      return input;
  }
   public static void printByFrequency(List<String> n){
      int sizeofstringlist=n.size();
      ArrayList<String> uniquenames=new ArrayList<String>();
      uniquenames.add(n.get(0));
      for(int i=1;i<sizeofstringlist;i++) {
       boolean processor=uniquenames.contains(n.get(i));	  
       if(processor==false) uniquenames.add(n.get(i));       
      }
      int uniquesize=uniquenames.size();
      uniquenames.sort(Comparator.comparing(String::toString));
      System.out.println("Size of original list "+n.size());
      System.out.println("Unique names: "+uniquesize);
      Map<String,Integer> namemap=new HashMap<>();
      String[] outputlist= new String[uniquesize];
      for(int i=0;i<uniquesize;i++) outputlist[i]="";
      for(String name: n) {
    	int index=namemap.getOrDefault(name, 0);
    	namemap.put(name, index+1);
      }
      LinkedHashMap<String, Integer> namemap2= new LinkedHashMap<>();
      namemap.entrySet().stream().sorted(Map.Entry.comparingByValue(Comparator.reverseOrder())).forEachOrdered(x -> namemap2.put(x.getKey(), x.getValue()));
      int counter=0;
      for(Map.Entry<String,Integer> t : namemap2.entrySet()) {
    	String key = t.getKey();
    	Integer value = t.getValue();
    	for(int i=0;i<value;i++) {
    	 outputlist[counter]=outputlist[counter]+(key+",");
    	}
    	counter++;
      }
      ArrayList<Integer> uniquecount=new ArrayList<>();
      Map.Entry<String,Integer> entry = namemap.entrySet().iterator().next();
      uniquecount.add(entry.getValue());
      for(Map.Entry<String,Integer> t : namemap2.entrySet()) {
    	Integer value=t.getValue();
    	boolean processor2=uniquecount.contains(value);	  
        if(processor2==false) uniquecount.add(value); 
      }
	  Collections.sort(uniquecount, Collections.reverseOrder());
      String[] namecounter=new String[uniquecount.size()];
      for(int i=0;i<uniquecount.size();i++) namecounter[i]="";
      for(int i=0;i<uniquecount.size();i++) {
    	ArrayList <String> counterlist=new ArrayList<String>();  
    	for(Map.Entry<String,Integer> t : namemap2.entrySet()) {
    	  String key=t.getKey();
    	  Integer value=t.getValue();
    	  if(value==uniquecount.get(i)) counterlist.add(key);
    	}
        counterlist.sort(Comparator.comparing(String::toString));
    	for(int k=0;k<counterlist.size();k++) namecounter[i]=namecounter[i]+counterlist.get(k)+",";
      }
      for(int i=0;i<namecounter.length;i++) {
      	System.out.println("Size: "+uniquecount.get(i));  
    	System.out.println(namecounter[i]);       }
      for(int i=0;i<uniquesize;i++) {
       System.out.println(outputlist[i]);	  
      }
   }
   public static int sumZero(int[] a) {
	int firstnum=-1;
	int asize=a.length;
	for(int i=0;i<asize;i++) {
	 for(int j=i+1;j<asize;j++) {
	  if((a[i]+a[j])==0) {
	   firstnum=i;
	   return firstnum;
	  }
	 }
	} 
	return firstnum;
   }
   public static void main(String[] args){
      List<String> names = readInFile("A3input.txt");
      printByFrequency(names);
      int[] num = {24,4,-243,-345,246,-45,-34,23,346,65,75,-73,-3,54,63,-35,-23,86,-4,29};
      int i = sumZero(num); //7. The actual sumzero value is 1
      if (i != -1)System.out.println("Pair value: " + num[i]);//4
      AVLtree<Integer> tr = new AVLtree<Integer>();
      tr.add(4);
      tr.add(5);
      System.out.println("Tree Height:" + tr.height());//1
      tr.print();
      tr.add(6);
      System.out.println("Tree Height:" + tr.height());//1
      tr.print();
      tr.add(1);
      System.out.println("Tree Height:" + tr.height());//2
      tr.print();
      tr.add(2);
      System.out.println("Tree Height:" + tr.height());//2
      tr.print();
      tr.add(0);
      System.out.println("Tree Height:" + tr.height());//2
      tr.print();
      tr.add(3);
      System.out.println("Tree Height:" + tr.height());//3
      tr.print();
      tr.print2();//2, 1, 0, 5, 4, 3, 6,
      Integer x = 1;
      Integer[] v1 = {x,x,x,null,null,x,x,null,x,null,null,null,null};
      Integer[] v2 = {x,x,null,x,x,x,null,x,x,null,x,null,null,x,x,null,null,null,x,null,null,x,x,x,null,null,null,null,null};
      Btree<Integer> bt = new Btree<Integer>(v1);
      System.out.println("Small tree longest zig zag: " + bt.longestZigZag()); //3 Didn't do extra credit
      bt = new Btree<Integer>(v2);
      System.out.println("Big tree longest zig zag: " + bt.longestZigZag()); //4 Didn't do extra credit
      Integer[] v3 = {3,2,6,1,null,5,7,null,null,4,null,null,null,null,null};//is avl
      bt = new Btree<Integer>(v3);
      if (bt.isAVLtree()) System.out.println("v3 answer is correct");
      else System.out.println("v3 answer is wrong");
      
      Integer[] v4 = {3,2,6,null,null,5,7,4,null,null,null,null,null};// not avl 
      bt = new Btree<Integer>(v4);
      if (bt.isAVLtree()) System.out.println("v4 answer is correct");
      else System.out.println("v4 answer is wrong");//initially correct and wrong were switched I switched them around as the original format was an error. 
   }
}