import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Stack;

class Btree<E>{
   private static class BNode<E>{
      private E element;
      private BNode<E> parent;
      private BNode<E> left;
      private BNode<E> right;
      public BNode(E e){
	  this(e, null, null);
     }
      public BNode(E e, BNode<E> l, BNode<E> r){
	 	element = e;
	 	left = l;
	 	right = r;
        }
      public E getE(){
	 return element;
      }
      public BNode<E> getParent(){
	 return parent;
      }
      public BNode<E> getLeft(){
	 return left;
      }
      public BNode<E> getRight(){
	 return right;
      }
      public void setE(E e){
	 element = e;
      }
      public void setParent(BNode<E> p){
	 parent = p;
      }
      public void setLeft(BNode<E> l){
	 left = l;
      }
      public void setRight(BNode<E> r){
	 right = r;
      }
   }
   public int findheight(BNode<E> r) {
   	if((r==null)) return 0;
   	else{
   	 return Math.max(findheight(r.left),findheight(r.right))+1;
       }
    }
  public void addnodesintoarray(BNode a,ArrayList<BNode> b) {
	 if(a!=null) {
	  b.add(a);
	  addnodesintoarray(a.left,b);
	  addnodesintoarray(a.right,b);
	 }
  }
   private BNode<E> root;
   private int size;
   public Btree(){
      root = null;
      size = -1;
   }
   public Btree(E[] v){
   		root = new BNode<E>(v[0]);
   		int l = v.length, i = 0;
   		ArrayDeque<BNode<E>> queue = new ArrayDeque<BNode<E>>();
   		queue.add(root);
   		while (++i < l){
   			BNode<E> n = queue.remove();
   			if (v[i] != null) {
   			   n.setLeft(new BNode<E>(v[i]));
   			   n.getLeft().setParent(n);
   			   queue.add(n.getLeft());
   			}
   			if (++i < l){
   				if (v[i] != null) {
   			   		n.setRight(new BNode<E>(v[i]));
   			   		n.getRight().setParent(n);
   			   		queue.add(n.getRight());
   				}
   			}
   		}
   
   }
   public boolean isAVLtree() {
	 ArrayList<BNode> nodelist=new ArrayList<BNode>();
	 addnodesintoarray(this.root,nodelist);
	 int nodelistsize=nodelist.size();
	 if(nodelistsize==0) return true;
	 else {
	  for(int i=0;i<nodelistsize;i++) {
		BNode current=nodelist.get(i);
		int nodedifference=Math.abs(findheight(current.left)-findheight(current.right));
        if(nodedifference>1) return false;
	  }
	  return true;
	 }
   }
	public BNode getroot() {
	 return root;	
	}
    public int longestZigZag(){
    	return 1;
    }
}